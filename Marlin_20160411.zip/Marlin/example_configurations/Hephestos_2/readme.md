# Example Configuration for BQ [Hephestos 2](http://www.bq.com/uk/hephestos-2)
This configuration file is based on the original configuration file shipped with the heavily modified Marlin fork by BQ. The original firmware and configuration file can be found at [BQ Github repository](https://github.com/bq/Marlin).

NOTE: The look and feel of the Hephestos 2 while navigating the LCD menu will change by using the original Marlin firmware.

## Changelog
 * 2016/03/01 - Initial release
 * 2016/03/21 - Activated four point auto leveling by default; updated miscellaneous z-probe values
